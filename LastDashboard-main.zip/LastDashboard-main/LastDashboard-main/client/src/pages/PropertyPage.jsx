import React from "react";
import TableWithActions from "../components/property/ProperyTable"

export default function Property() {
    return (
      <main className="grid gap-4 p-4 ">
  
        <TableWithActions/>
        
      </main>
    );
  }